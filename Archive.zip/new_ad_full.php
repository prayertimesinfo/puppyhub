<?php
include_once ('config_mysite.php');
$category=intval($_GET['category']);
$type=intval($_GET['type']);
if(!$category || !$type){
    header("Location: new_ad.php");
    exit;
}

$have_sub=0;
$check_sub=$conn->query("select * from `sub_category` where `type_id`='$type' and `category_id`='$category' limit 1");
if($row_check_sub=$check_sub->fetch_assoc()){
    $have_sub=1;
}

$upload_photo=0;
if($category==1 ||$category==4 ||$category==5 ||$category==6 ||$category==7){
    $upload_photo=1;
}

if($_POST){
    extract($_POST);
    $sub_category=clear_var($sub_category);
    $country=clear_var($country);
    $province=clear_var($origin_city_prov);
    $city=clear_var($city);
    $title=clear_var($title);
    $description=clear_var($description);
    $salary=clear_var($salary);
    $price=clear_var($price);
    $email=clear_var($email);
    $number=clear_var($number);

    if($have_sub==1 && !$sub_category){
        $note='<div class="alert alert-danger"><i class="fa fa-info-circle"></i> Please select sub category</div>';
    }
    else{
        if($country && $city && $title && $description && $email){
            //check correct city & country
            $check_city=$conn->query("select * from `world_city` where `city`='$city' and `country` like '$country' limit 1");
            if($row_check_city=$check_city->fetch_assoc()){
                //Correct location
                $select_cat=$conn->query("select `link` from `category` where `id`='$category'");
                $row_cat=$select_cat->fetch_assoc();
                $category_link=$row_cat['link'];
                $select_type=$conn->query("select `link` from `type` where `id`='$type'");
                $row_type=$select_type->fetch_assoc();
                $type_link=$row_type['link'];
                if($sub_category){
                    $select_subcat=$conn->query("select `link` from `sub_category` where `id`='$sub_category'");
                    $row_subcat=$select_subcat->fetch_assoc();
                    $sub_category_link=$row_subcat['link'];
                }

                if($category==2 || $category==3)
                    $insert=$conn->query("insert into `jobs` (`title`,`description`,`category`,`type`,`category_id`,`type_id`,`salary`,`email`,`number`,`user_id`,`country`,`province`,`city`,`date`) values ('$title','$description','$category_link','$type_link','$category','$type','$salary','$email','$number','$__user_id','$country','$province','$city',now())");
                else{
                    if($category==4)
                        $table='housing';
                    else
                        $table='classifieds';
                    $insert=$conn->query("insert into `$table` (`title`,`description`,`category`,`type`,`sub_category`,`category_id`,`type_id`,`subcat_id`,`price`,`email`,`number`,`user_id`,`country`,`province`,`city`,`date`) values ('$title','$description','$category_link','$type_link','$sub_category_link','$category','$type','$sub_category','$price','$email','$number','$__user_id','$country','$province','$city',now())");
                    echo $conn->error;
                    $ad_id=$conn->insert_id;
                    $this_image_id = $ad_id . '_' . time();
                    $this_img_width=600;
                    if ($_FILES['photo']['type'] == 'image/gif' || $_FILES['photo']['type'] == 'image/png' || $_FILES['photo']['type'] == 'image/jpg' || $_FILES['photo']['type'] == 'image/pjpeg' || $_FILES['photo']['type'] == 'image/jpeg' || $_FILES['photo']['type'] == 'image/bmp') {
                        $image_id="1_$this_image_id";
                        if ($_FILES["photo"]["type"] == "image/gif") {
                            $move = move_uploaded_file($_FILES["photo"]["tmp_name"], "$__ads_path/$image_id.gif");
                            $image_link = "$__ads_path/" . $image_id . ".gif";
                        } elseif ($_FILES["photo"]["type"] == "image/png") {
                            $move = move_uploaded_file($_FILES["photo"]["tmp_name"], "$__ads_path/$image_id.png");
                            $image_link = "$__ads_path/" . $image_id . ".png";
                        } elseif ($_FILES["photo"]["type"] == "image/bmp") {
                            $move = move_uploaded_file($_FILES["photo"]["tmp_name"], "$__ads_path/$image_id.bmp");
                            $image_link = "$__ads_path/" . $image_id . ".bmp";
                        } else {
                            $move = move_uploaded_file($_FILES["photo"]["tmp_name"], "$__ads_path/$image_id.jpg");
                            $image_link = "$__ads_path/" . $image_id . ".jpg";
                        }
                        resizePicture("$image_link", "$image_link", $this_img_width);
                        $update_image = $conn->query("update `$table` set `photo`='$image_link' where `id`='$ad_id'");
                    }

                    if ($_FILES['photo2']['type'] == 'image/gif' || $_FILES['photo2']['type'] == 'image/png' || $_FILES['photo2']['type'] == 'image/jpg' || $_FILES['photo2']['type'] == 'image/pjpeg' || $_FILES['photo2']['type'] == 'image/jpeg' || $_FILES['photo2']['type'] == 'image/bmp') {
                        $image_id="2_$this_image_id";
                        if ($_FILES["photo2"]["type"] == "image/gif") {
                            $move = move_uploaded_file($_FILES["photo2"]["tmp_name"], "$__ads_path/$image_id.gif");
                            $image_link = "$__ads_path/" . $image_id . ".gif";
                        } elseif ($_FILES["photo2"]["type"] == "image/png") {
                            $move = move_uploaded_file($_FILES["photo2"]["tmp_name"], "$__ads_path/$image_id.png");
                            $image_link = "$__ads_path/" . $image_id . ".png";
                        } elseif ($_FILES["photo2"]["type"] == "image/bmp") {
                            $move = move_uploaded_file($_FILES["photo2"]["tmp_name"], "$__ads_path/$image_id.bmp");
                            $image_link = "$__ads_path/" . $image_id . ".bmp";
                        } else {
                            $move = move_uploaded_file($_FILES["photo2"]["tmp_name"], "$__ads_path/$image_id.jpg");
                            $image_link = "$__ads_path/" . $image_id . ".jpg";
                        }
                        resizePicture("$image_link", "$image_link", $this_img_width);
                        $update_image = $conn->query("update `$table` set `photo2`='$image_link' where `id`='$ad_id'");
                    }

                    if ($_FILES['photo3']['type'] == 'image/gif' || $_FILES['photo3']['type'] == 'image/png' || $_FILES['photo3']['type'] == 'image/jpg' || $_FILES['photo3']['type'] == 'image/pjpeg' || $_FILES['photo3']['type'] == 'image/jpeg' || $_FILES['photo3']['type'] == 'image/bmp') {
                        $image_id="3_$this_image_id";
                        if ($_FILES["photo3"]["type"] == "image/gif") {
                            $move = move_uploaded_file($_FILES["photo3"]["tmp_name"], "$__ads_path/$image_id.gif");
                            $image_link = "$__ads_path/" . $image_id . ".gif";
                        } elseif ($_FILES["photo3"]["type"] == "image/png") {
                            $move = move_uploaded_file($_FILES["photo3"]["tmp_name"], "$__ads_path/$image_id.png");
                            $image_link = "$__ads_path/" . $image_id . ".png";
                        } elseif ($_FILES["photo3"]["type"] == "image/bmp") {
                            $move = move_uploaded_file($_FILES["photo3"]["tmp_name"], "$__ads_path/$image_id.bmp");
                            $image_link = "$__ads_path/" . $image_id . ".bmp";
                        } else {
                            $move = move_uploaded_file($_FILES["photo3"]["tmp_name"], "$__ads_path/$image_id.jpg");
                            $image_link = "$__ads_path/" . $image_id . ".jpg";
                        }
                        resizePicture("$image_link", "$image_link", $this_img_width);
                        $update_image = $conn->query("update `$table` set `photo3`='$image_link' where `id`='$ad_id'");
                    }

                    if ($_FILES['photo4']['type'] == 'image/gif' || $_FILES['photo4']['type'] == 'image/png' || $_FILES['photo4']['type'] == 'image/jpg' || $_FILES['photo4']['type'] == 'image/pjpeg' || $_FILES['photo4']['type'] == 'image/jpeg' || $_FILES['photo4']['type'] == 'image/bmp') {
                        $image_id="4_$this_image_id";
                        if ($_FILES["photo4"]["type"] == "image/gif") {
                            $move = move_uploaded_file($_FILES["photo4"]["tmp_name"], "$__ads_path/$image_id.gif");
                            $image_link = "$__ads_path/" . $image_id . ".gif";
                        } elseif ($_FILES["photo4"]["type"] == "image/png") {
                            $move = move_uploaded_file($_FILES["photo4"]["tmp_name"], "$__ads_path/$image_id.png");
                            $image_link = "$__ads_path/" . $image_id . ".png";
                        } elseif ($_FILES["photo4"]["type"] == "image/bmp") {
                            $move = move_uploaded_file($_FILES["photo4"]["tmp_name"], "$__ads_path/$image_id.bmp");
                            $image_link = "$__ads_path/" . $image_id . ".bmp";
                        } else {
                            $move = move_uploaded_file($_FILES["photo4"]["tmp_name"], "$__ads_path/$image_id.jpg");
                            $image_link = "$__ads_path/" . $image_id . ".jpg";
                        }
                        resizePicture("$image_link", "$image_link", $this_img_width);
                        $update_image = $conn->query("update `$table` set `photo4`='$image_link' where `id`='$ad_id'");
                    }

                    if ($_FILES['photo5']['type'] == 'image/gif' || $_FILES['photo5']['type'] == 'image/png' || $_FILES['photo5']['type'] == 'image/jpg' || $_FILES['photo5']['type'] == 'image/pjpeg' || $_FILES['photo5']['type'] == 'image/jpeg' || $_FILES['photo5']['type'] == 'image/bmp') {
                        $image_id="5_$this_image_id";
                        if ($_FILES["photo5"]["type"] == "image/gif") {
                            $move = move_uploaded_file($_FILES["photo5"]["tmp_name"], "$__ads_path/$image_id.gif");
                            $image_link = "$__ads_path/" . $image_id . ".gif";
                        } elseif ($_FILES["photo5"]["type"] == "image/png") {
                            $move = move_uploaded_file($_FILES["photo5"]["tmp_name"], "$__ads_path/$image_id.png");
                            $image_link = "$__ads_path/" . $image_id . ".png";
                        } elseif ($_FILES["photo5"]["type"] == "image/bmp") {
                            $move = move_uploaded_file($_FILES["photo5"]["tmp_name"], "$__ads_path/$image_id.bmp");
                            $image_link = "$__ads_path/" . $image_id . ".bmp";
                        } else {
                            $move = move_uploaded_file($_FILES["photo5"]["tmp_name"], "$__ads_path/$image_id.jpg");
                            $image_link = "$__ads_path/" . $image_id . ".jpg";
                        }
                        resizePicture("$image_link", "$image_link", $this_img_width);
                        $update_image = $conn->query("update `$table` set `photo5`='$image_link' where `id`='$ad_id'");
                    }

                    if ($_FILES['photo6']['type'] == 'image/gif' || $_FILES['photo6']['type'] == 'image/png' || $_FILES['photo6']['type'] == 'image/jpg' || $_FILES['photo6']['type'] == 'image/pjpeg' || $_FILES['photo6']['type'] == 'image/jpeg' || $_FILES['photo6']['type'] == 'image/bmp') {
                        $image_id="6_$this_image_id";
                        if ($_FILES["photo6"]["type"] == "image/gif") {
                            $move = move_uploaded_file($_FILES["photo6"]["tmp_name"], "$__ads_path/$image_id.gif");
                            $image_link = "$__ads_path/" . $image_id . ".gif";
                        } elseif ($_FILES["photo6"]["type"] == "image/png") {
                            $move = move_uploaded_file($_FILES["photo6"]["tmp_name"], "$__ads_path/$image_id.png");
                            $image_link = "$__ads_path/" . $image_id . ".png";
                        } elseif ($_FILES["photo6"]["type"] == "image/bmp") {
                            $move = move_uploaded_file($_FILES["photo6"]["tmp_name"], "$__ads_path/$image_id.bmp");
                            $image_link = "$__ads_path/" . $image_id . ".bmp";
                        } else {
                            $move = move_uploaded_file($_FILES["photo6"]["tmp_name"], "$__ads_path/$image_id.jpg");
                            $image_link = "$__ads_path/" . $image_id . ".jpg";
                        }
                        resizePicture("$image_link", "$image_link", $this_img_width);
                        $update_image = $conn->query("update `$table` set `photo6`='$image_link' where `id`='$ad_id'");
                    }
                }
                $note='<div class="alert alert-success"><i class="fa fa-check"></i> Ad saved successfully</div>';
            }
            else {
                $note='<div class="alert alert-danger"><i class="fa fa-info-circle"></i> Please select correct location</div>';
            }
        }
        else{
            $note='<div class="alert alert-danger"><i class="fa fa-info-circle"></i> Please enter all mandatory fields</div>';
        }
    }
}

//Header
include_once ('html/header.php');
?>
<!-- category-section -->
<section class="login-section signup-section bg-color-2">
    <div class="auto-container">
        <div class="inner-container" style="max-width: 750px;">
            <div class="inner-box">
                <h1>Post a free ad [step 2]</h1>
                <div class="form-group">
                <a href="new_ad.php"><i class="fa fa-arrow-alt-circle-left"></i> Change category</a>
                </div>
                <form method="POST" enctype="multipart/form-data">
                    <?php
                    echo $note;
                    if($have_sub==1)
                    {
                    ?>
                    <div class="form-group select-group">
                        <label>Sub Category <span class="man">*</span></label>
                        <i class="icon-30"></i>
                        <select class="wide" name="sub_category" id="category">
                            <option value="" data-display="Select sub Category"></option>
                            <?php
                            $select_subcat=$conn->query("select * from `sub_category` where `type_id`='$type' and `category_id`='$category'");
                            while ($row_subcat=$select_subcat->fetch_assoc())
                            {
                                echo '<option value="'.$row_subcat['id'].'">'.$row_subcat['name'].'</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <?php
                    }
                    ?>
                    <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Country <span class="man">*</span></label>
                            <input type="text" id="origin_country" value="" name="country" onkeyup="get_origin_country(this.value)" required/>
                            <div class="selector" id="country_selector"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>City <span class="man">*</span></label>
                            <input type="text" id="origin_city" value="" name="city" onkeyup="get_origin_city(this.value)" required/>
                            <div class="selector" id="city_selector"></div>
                        </div>
                    </div>
                    </div>


                    <input type="hidden" name="origin_city_prov" id="origin_city_prov"/>
                    <div class="form-group">
                        <label>Title <span class="man">*</span></label>
                        <input type="text" name="title" required/>
                    </div>
                    <div class="form-group">
                        <label>Description <span class="man">*</span></label>
                        <textarea name="description" class="form-control" required></textarea>
                    </div>
                    <?php
                    if($category==2 || $category==3) {
                    ?>
                    <div class="form-group">
                        <label>Salary <span class="man">*</span></label>
                        <input type="text" name="salary" required/>
                    </div>
                    <?php
                    }
                    else{
                    ?>
                    <div class="form-group">
                        <label>Price:</label>
                        <input type="text" name="price"/>
                    </div>
                    <?php
                    if($upload_photo==1)
                    {
                    ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>photo 1:</label>
                                    <input type="file" name="photo"/>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>photo 2:</label>
                                    <input type="file" name="photo2"/>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>photo 3:</label>
                                    <input type="file" name="photo3"/>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>photo 4:</label>
                                    <input type="file" name="photo4"/>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>photo 5:</label>
                                    <input type="file" name="photo5"/>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>photo 6:</label>
                                    <input type="file" name="photo6"/>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                    }
                    ?>
                    <div class="form-group">
                        <label>Email <span class="man">*</span></label>
                        <input type="email" name="email" required/>
                    </div>
                    <div class="form-group">
                        <label>Contact Number </label>
                        <input type="text" name="number"/>
                    </div>
                    <button class="btn btn-success"><i class="fa fa-paper-plane"></i> Post your ad</button>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- category-section end -->
<?php include_once ('html/footer.php');?>
