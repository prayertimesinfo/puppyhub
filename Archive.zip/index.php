<?php
include_once ('config_mysite.php');


//Header
include_once ('html/header.php');
?>
<!-- category-section -->
<section class="section sec-pad3">
    <div class="auto-container">
        <div class="sec-title">
            <span>Categories</span>
            <h2>Explore by Category</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing sed do eiusmod tempor incididunt labore <br />dolore magna aliqua enim.</p>
        </div>
    </div>
</section>
<!-- category-section end -->
<?php include_once ('html/footer.php');?>
