<!-- main-footer -->
<footer class="main-footer">
    <div class="footer-bottom">
        <div class="auto-container">
            <div class="footer-inner clearfix">
                <div class="copyright pull-left"><p><img src="images/logow.png" style="height:30px;"> &copy; <?php echo date('Y');?> All Right Reserved</p></div>
                <ul class="footer-nav pull-right clearfix">
                    <li><a href="#">Terms of Service</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<!-- main-footer end -->



<!--Scroll to top-->
<button class="scroll-top scroll-to-target" data-target="html">
    <span class="far fa-long-arrow-up"></span>
</button>
</div>

<!-- jequery plugins -->
<script src="assets/js/jquery.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/owl.js"></script>
<script src="assets/js/wow.js"></script>
<script src="assets/js/validation.js"></script>
<!--<script src="assets/js/jquery.fancybox.js"></script>-->
<script src="assets/js/appear.js"></script>
<script src="assets/js/scrollbar.js"></script>
<script src="assets/js/jquery.nice-select.min.js"></script>
<!--<script src="//code.jquery.com/jquery-1.12.4.js"></script>-->
<script src="assets/js/jquery-ui.js"></script>
<!-- main-js -->
<script src="assets/js/script.js"></script>
<script src="assets/js/custom_script.js"></script>


<script src="dist/simple-lightbox.js?v2.8.0"></script>
<script type="text/javascript">
    (function() {
        var $gallery = new SimpleLightbox('.gallery a', {});
    })();
</script>

<script>
    $(".favorite-btn").click(function () {
        var id=$(this).data('id');
        var item=$(this).data('item');
        if($(this).hasClass("active"))
            $(this).removeClass("active");
        else
            $(this).addClass("active");
        $.ajax({
            url: "ajax_favorites.php",
            data: 'id='+id+'&item='+item,
            type: 'GET',
            success: function (Res) {
                console.log(Res);
            }
        });
    });
</script>
</body><!-- End of .page_wrapper -->
</html>