<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <title><?php if($page_title) echo $page_title; else echo 'Puppies for sale, find your dream puppy | PuppyHub.org';?></title>
    <base href="/puppyhub.org/"/>
    <!-- Fav Icon -->
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,300;0,400;0,600;0,700;0,800;0,900;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Stylesheets -->
    <link href="assets/css/font-awesome-all.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/owl.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
<!--    <link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">-->
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/color.css" rel="stylesheet">

    <link href="assets/css/jquery-ui.css" rel="stylesheet">

    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">

    <link rel="stylesheet" href="dist/simple-lightbox.css?v2.8.0" />
</head>

<?php
if(!$_SESSION['user'])
{
$__account_links='
<a href="login.php" class="theme-btn-one"><i class="fa fa-user-lock"></i> Login</a>
<a href="signup.php" class="theme-btn-one"><i class="fa fa-user-plus"></i> Signup</a>
<a href="login.php" class="theme-btn-one orange"><i class="fa fa-plus"></i> Post your ad</a>
';
}
else
{
$__account_links='
<a href="account.php" class="theme-btn-one"><i class="fa fa-user"></i> Welcome '.$__username.'</a>
<a href="javascript:;" class="theme-btn-one orange"><i class="fa fa-plus"></i> Post your ad</a>
<a href="logout.php" class="theme-btn-one out"><i class="fa fa-sign-out"></i> logout</a>
';
}
?>
<!-- page wrapper -->
<body>

<div class="boxed_wrapper">


    <!-- preloader -->
<!--    <div class="preloader"></div>-->
    <!-- preloader -->


    <!-- main header -->
    <header class="main-header">

        <!-- header-lower -->
        <div class="header-lower">
            <div class="auto-container">
                <div class="outer-box">
                    <div class="logo-box">
                        <figure class="logo"><a href="index.php"><img src="images/logo.png" alt=""></a></figure>
                    </div>
                    <div class="menu-area">
                        <!--Mobile Navigation Toggler-->
                        <div class="mobile-nav-toggler">
                            <i class="icon-bar"></i>
                            <i class="icon-bar"></i>
                            <i class="icon-bar"></i>
                        </div>
<!--                        <nav class="main-menu navbar-expand-md navbar-light">-->
<!--                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">-->
<!--                                <ul class="navigation clearfix">-->
<!--                                    <li class="current dropdown"><a href="index.php">Home</a>-->
<!--                                        <ul>-->
<!--                                            <li><a target="_blank" href="__design_files/index.html">Home Page 01</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/index-2.html">Home Page 02</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/index-3.html">Home Page 03</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/index-4.html">Home Page 04</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/index-5.html">Home Page 05</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/index-6.html">Home Page 06</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/index-onepage.html">OnePage Home</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/index-rtl.html">RTL Home</a></li>-->
<!--                                            <li class="dropdown"><a href="index.php">Header Style</a>-->
<!--                                                <ul>-->
<!--                                                    <li><a target="_blank" href="__design_files/index.html">Header Style 01</a></li>-->
<!--                                                    <li><a target="_blank" href="__design_files/index-2.html">Header Style 02</a></li>-->
<!--                                                    <li><a target="_blank" href="__design_files/index-3.html">Header Style 03</a></li>-->
<!--                                                    <li><a target="_blank" href="__design_files/index-4.html">Header Style 04</a></li>-->
<!--                                                </ul>-->
<!--                                            </li>-->
<!--                                        </ul>-->
<!--                                    </li>-->
<!--                                    <li class="dropdown"><a href="index.php">Categories</a>-->
<!--                                        <ul>-->
<!--                                            <li><a target="_blank" href="__design_files/category.html">All Category</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/category-details.html">Category Details</a></li>-->
<!--                                        </ul>-->
<!--                                    </li>-->
<!--                                    <li class="dropdown"><a href="index.php">Browse Ads</a>-->
<!--                                        <ul>-->
<!--                                            <li><a target="_blank" href="__design_files/browse-ads-1.html">Browse Ads Grid</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/browse-ads-2.html">Browse Ads List</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/browse-ads-3.html">Grid Half</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/browse-ads-4.html">List Half</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/browse-ads-details.html">Browse Ads Details</a></li>-->
<!--                                        </ul>-->
<!--                                    </li>-->
<!--                                    <li class="dropdown"><a href="index.php">Pages</a>-->
<!--                                        <ul>-->
<!--                                            <li><a target="_blank" href="__design_files/about.html">About Us</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/stores.html">Our Stores</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/stores-details.html">Stores Details</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/faq.html">Faq'S</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/pricing.html">Pricing Table</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/login.html">Login Page</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/signup.html">Signup Page</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/contact.html">Contact Us</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/error.html">404</a></li>-->
<!--                                        </ul>-->
<!--                                    </li>-->
<!--                                    <li class="dropdown"><a href="index.php">Elements</a>-->
<!--                                        <div class="megamenu">-->
<!--                                            <div class="row clearfix">-->
<!--                                                <div class="col-xl-6 column">-->
<!--                                                    <ul>-->
<!--                                                        <li><h4>Elements 1</h4></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/about-element.html">About Block</a></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/category-element-1.html">Category Block 01</a></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/category-element-2.html">Category Block 02</a></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/category-element-3.html">Category Block 03</a></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/place-element-1.html">Place Block 01</a></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/place-element-2.html">Place Block 02</a></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/news-element-1.html">News Block 01</a></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/news-element-2.html">News Block 02</a></li>-->
<!--                                                    </ul>-->
<!--                                                </div>-->
<!--                                                <div class="col-xl-6 column">-->
<!--                                                    <ul>-->
<!--                                                        <li><h4>Elements 2</h4></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/feature-element-1.html">Feature Block 01</a></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/feature-element-2.html">Feature Block 02</a></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/Process-element-1.html">Process Block 01</a></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/Process-element-2.html">Process Block 02</a></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/testimonial-element.html">Testimonial Block</a></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/clients-element.html">Clients Block</a></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/newsletter-element.html">Newsletter Block</a></li>-->
<!--                                                        <li><a target="_blank" href="__design_files/chooseus-element.html">Chooseus Block</a></li>-->
<!--                                                    </ul>-->
<!--                                                </div>-->
<!--                                            </div>-->
<!--                                        </div>-->
<!--                                    </li>-->
<!--                                    <li class="dropdown"><a href="index.php">Blog</a>-->
<!--                                        <ul>-->
<!--                                            <li><a target="_blank" href="__design_files/blog.html">Blog Grid</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/blog-2.html">Blog Standard</a></li>-->
<!--                                            <li><a target="_blank" href="__design_files/blog-details.html">Blog Details</a></li>-->
<!--                                        </ul>-->
<!--                                    </li>-->
<!--                                </ul>-->
<!--                            </div>-->
<!--                        </nav>-->
                    </div>
                    <div class="btn-box">
                        <?php
                        echo $__account_links;
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <!--sticky Header-->
        <div class="sticky-header">
            <div class="auto-container">
                <div class="outer-box">
                    <div class="logo-box">
                        <figure class="logo"><a href="index.php"><img src="images/logo.png" alt=""></a></figure>
                    </div>
                    <div class="menu-area">
                        <nav class="main-menu clearfix">
                            <!--Keep This Empty / Menu will come through Javascript-->
                        </nav>
                    </div>
                    <div class="btn-box">
                        <?php
                        echo $__account_links;
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- main-header end -->

    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <div class="close-btn"><i class="fas fa-times"></i></div>

        <nav class="menu-box">
            <div class="nav-logo"><a href="index.php"><img src="images/logow.png" alt="" title=""></a></div>
            <div class="btn-box">
                <?php
                echo $__account_links;
                ?>
            </div>
            <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>

        </nav>
    </div><!-- End Mobile Menu -->